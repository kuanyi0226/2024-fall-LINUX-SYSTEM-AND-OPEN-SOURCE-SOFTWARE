#pragma once

char *reverse(char *dest, const char *src);
